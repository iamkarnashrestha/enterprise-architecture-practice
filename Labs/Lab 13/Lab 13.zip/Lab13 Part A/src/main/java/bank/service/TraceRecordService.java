package bank.service;

import bank.domain.TraceRecord;

public interface TraceRecordService {
    public void saveTraceRecord(TraceRecord traceRecord);
}
