package lab13partC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab13partCApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab13partCApplication.class, args);
	}

}
